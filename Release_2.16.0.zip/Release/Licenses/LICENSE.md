This library is dual-licensed:
- GNU Affero General Public License version 3 - see agpl-3.0.txt for more details
- Commercial license, contact tdt@dannyhaak.nl for more details

The included XML and XSD artifacts are (c) by GS1 (https://www.gs1.org/epc/tag-data-translation-standard).